A Pen created at CodePen.io. You can find this one at https://codepen.io/hiennguyen1996/pen/MLXEoz.

 This function is built up mostly by javascript instead of css and html