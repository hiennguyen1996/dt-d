//Controller
/*
var controller;
var loop; 
var circle; 
*/

//Canvas Properties
var canvas = document.getElementById("my-canvas"); 
var ctx = canvas.getContext("2d");
canvas.width = 600;
canvas.height = 300; 

//Circle Properties

var x = canvas.width/7;  //position x 
var y = canvas.height-30;  //position y
var circleRadius = 30; //radius 

//Circle move 

var dx= 4; 
var dy= 0 ; 

//Drawing a Circle 

function drawCircle() 
{
  ctx.beginPath(); 
  ctx.arc(x, y, circleRadius, 0, Math.PI * 2);
  ctx.fillStyle = "orange"; 
  ctx.fill(); 
  ctx.closePath();
  window.requestAnimationFrama(loop); 
}


drawCircle();

requestAnimationFrame(draw); 

function draw()
{   
 ctx.clearRect(0, 0, canvas.width, canvas.height ); 
  x +=dx;
  y +=dy; 
  drawCircle(); 
  requestAnimationFrame(draw); 
}


//circle properties
/*
circle = {
  jumping:true,
  x_velocity:0,
  y_velocity:0
  
};

*/

//controller properties
/*
controller = {
   left: false, 
   right: false,
   up:false, 
   keyListener: function(event){
      var key_state = (event.type == "keydown") ?true:false;
     
     switch(event.keyCode){
         
       case 1: // left key 
         controller.left = key_state;
       break;
       case 2: // up key
          controller.up = key_state; 
       break;
       case 3: // right key
          controller.right = key_state; 
       break;
     }
   }
};
*/
//loop function 
/*
 loop = function() {
   if (controller.up && circle.jumping == false) {
     
     circle.y_velocity -=20;
     circle.jumping = true; 
   }
   if (controller.left){
     circle.x_velocity -=0.5;
   }
   if (controller.right){
     circle.x_velocity +=0.5; 
   }
   
   circle.y_velocity += 1.5; //gravity
   circle.x += circle.x_velocity; 
   circle.y += circle.y_velocity;
   circle.x_velocity *=0.9; //friction
   circle.y_velocity *= 0.9; //friction
   */
   
   // prevent cirle falling below canvas floor 
   /*
   if (circle.y > 180 - 16 - 32){
     
     circle.jumping = false; 
     circle.y = 180-16-32;
     circle.y_velocity = 0;
   }*/
   
   //prevent is going over the left of the screen
   /*
   if (circle.x < -32){
     circle.x =320;
   } else if (circle.x>320){
     rectangle.x = -32; 
   }
   */
   /*
  ctx.beginPath(); 
  ctx.arc(x, y, circleRadius, 0, Math.PI * 2);
  ctx.fillStyle = "orange"; 
  ctx.fill(); 
  ctx.moveTo(0, 164);
  ctx.lineTo(320, 164); 
  ctx.closePath();
   
  window.requestAnimationFrame(loop); 
   
 };
*/
// call update when the browser is ready to draw again 

// keyboard events
/*
window.addEventListener("keydown", controller.keyListener);
window.addEventListener("keyup", controller.keyListener);
window.requestAnimationFrame(loop); */